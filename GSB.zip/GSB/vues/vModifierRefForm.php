<!--Formulaire de modification à partir de l'identifiant -->

<div class="container">

<form action="" method=post>
<fieldset>
<legend>Entrez le matricule du visiteur à modifier </legend>
<label>Matricule :</label> <input type="text" autofocus required=""  name="VIS_MATRICULE" size="10" />
</fieldset>
<button type="submit" class="btn btn-primary">Modifier</button>
<button type="reset" class="btn">Annuler</button>
</form>

</div>
