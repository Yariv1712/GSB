  

<div class="jumbotron masthead">
  <div class="container">
    <h1>GSB</h1>
    
    <hr>
    <p>Envoyez des fleurs avec Lafleur.</p>
  </div>
</div>
