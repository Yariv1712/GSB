
<!--Saisir les informations dans un formulaire!-->
<div class="container">
  <form name="formAjout" action="" method="post">
    <fieldset>
      <legend>Entrez vos coordonnées pour l'inscription </legend>
      <label> Nom : </label> <input type="text" name="nom" size="15" />
      <label> Mot de passe :</label> <input type="password" name="mdp" size="15" />
      <label> Mot de passe (*) :</label> <input type="password" name="mdp2" size="15" />
      <label> (*) à entrer à nouveau </label>
  
    </fieldset>
    <button type="submit" class="btn btn-primary">Enregistrer</button>
    <button type="reset" class="btn">Annuler</button>
  </form>
</div>
