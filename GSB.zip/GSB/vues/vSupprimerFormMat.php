<!--Formulaire de suppression à partir de l'identifiant -->

<div class="container">

<form action="" method=post>
<fieldset>
<legend>Entrez la référence du materiel  à supprimer </legend>
<label>Matricule :</label> <input type="text" name="ref" size="10" autofocus required="" />
</fieldset>
<button type="submit" class="btn btn-primary">Supprimer</button>
<button type="reset" class="btn">Annuler</button>
</form>

</div>
<!-- https://openclassrooms.com/forum/sujet/liste-deroulantes-dependantes-d-une-base-de-donnees-14636 -->