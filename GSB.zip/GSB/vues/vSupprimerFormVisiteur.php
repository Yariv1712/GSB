<!--Formulaire de suppression à partir de l'identifiant -->

<div class="container">

<form action="" method=post>
<fieldset>
<legend>Entrez le matricule du visiteur  à supprimer </legend>
<label>Matricule :</label> <input type="text" name="mat" size="10" autofocus required=""/>
</fieldset>
<button type="submit" class="btn btn-primary">Supprimer</button>
<button type="reset" class="btn">Annuler</button>
</form>

</div>
