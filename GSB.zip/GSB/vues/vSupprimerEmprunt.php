<!--Formulaire de suppression à partir de l'identifiant -->

<div class="container">

<form action="" method=post>
<fieldset>
    <legend>Entrez les données sur le visiteur et le matériel à restituer</legend>
    <label> Reference du matériel: </label> <input type="text" placeholder=""name="RefMat" size="10" /><br />
</fieldset>
<button type="submit" class="btn btn-primary">Supprimer</button>
<button type="reset" class="btn">Annuler</button>
</form>

</div>
