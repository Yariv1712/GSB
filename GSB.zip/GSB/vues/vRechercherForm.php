<!--Formulaire de recherche à partir du nom-->

<div class="container">
  <form class="form-search" action="" method=post>
    <legend>Entrez le nom du visiteur à rechercher </legend>
    <div class="input-append">
      <input type="text" class="input-medium search-query" name="nom" autofocus required="">
      <button type="submit" class="btn btn-primary">Rechercher</button>
    </div>
  </form>
</div>
