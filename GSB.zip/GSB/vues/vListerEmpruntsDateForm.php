<!--Formulaire de recherche à partir du nom-->

<div class="container">
  <form class="form-search" action="" method=post>
    <legend>Entrez la date</legend>
    <div class="input-append">
      <input type="date" class="input-medium search-query" name="dateList" autofocus required="">
      <button type="submit" class="btn btn-primary">Lister</button>
    </div>
  </form>
</div>